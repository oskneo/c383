package blockchain

import (
	"github.com/stretchr/testify/assert"
	"testing"
)

// TODO: some useful tests of Blocks
